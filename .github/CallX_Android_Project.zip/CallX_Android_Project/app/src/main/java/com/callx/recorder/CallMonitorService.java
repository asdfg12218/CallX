package com.callx.recorder;

import android.app.*;
import android.content.*;
import android.media.MediaRecorder;
import android.os.*;
import android.telephony.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CallMonitorService extends Service {
    public static final String ACTION_START = "com.callx.START";
    public static final String ACTION_STOP = "com.callx.STOP";
    private static final String CHANNEL = "callx_status";
    private TelephonyManager telephony;
    private PhoneStateListener listener;
    private MediaRecorder recorder;
    private boolean recording = false;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int id) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopRecording();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        startForeground(7, notification("پایش تماس روشن است"));
        registerPhoneListener();
        return START_STICKY;
    }

    private void registerPhoneListener() {
        telephony = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        listener = new PhoneStateListener() {
            @Override public void onCallStateChanged(int state, String number) {
                if (state == TelephonyManager.CALL_STATE_RINGING ||
                    state == TelephonyManager.CALL_STATE_OFFHOOK) {
                    if (!recording) startRecording();
                } else if (state == TelephonyManager.CALL_STATE_IDLE) {
                    stopRecording();
                }
            }
        };
        try {
            telephony.listen(listener, PhoneStateListener.LISTEN_CALL_STATE);
        } catch (SecurityException e) {
            updateNotification("مجوز وضعیت تماس در دسترس نیست");
        }
    }

    private void startRecording() {
        if (recording) return;
        try {
            File dir = new File(getExternalFilesDir(null), "CallX");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("پوشه ذخیره‌سازی ساخته نشد");
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            File out = new File(dir, "CallX_" + stamp + ".m4a");

            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(128000);
            recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(out.getAbsolutePath());
            recorder.prepare();
            recorder.start();
            recording = true;
            updateNotification("در حال ضبط میکروفون؛ تماس را با اطلاع طرف مقابل ضبط کنید");
        } catch (Exception e) {
            recording = false;
            if (recorder != null) {
                try { recorder.reset(); recorder.release(); } catch (Exception ignored) {}
                recorder = null;
            }
            updateNotification("ضبط شروع نشد؛ ممکن است میکروفون در اختیار برنامه تلفن باشد");
        }
    }

    private void stopRecording() {
        if (recorder != null) {
            try {
                if (recording) recorder.stop();
            } catch (RuntimeException ignored) {
                // Discard a broken/too-short recording rather than leaving a corrupt file.
            }
            try { recorder.reset(); recorder.release(); } catch (Exception ignored) {}
            recorder = null;
        }
        recording = false;
        updateNotification("پایش تماس روشن است؛ فعلاً ضبطی انجام نمی‌شود");
    }

    private void updateNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.notify(7, notification(text));
    }

    private Notification notification(String text) {
        return new Notification.Builder(this, CHANNEL)
            .setContentTitle("CallX")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "وضعیت CallX", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    @Override public void onDestroy() {
        stopRecording();
        if (telephony != null && listener != null) telephony.listen(listener, PhoneStateListener.LISTEN_NONE);
        super.onDestroy();
    }

    @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
