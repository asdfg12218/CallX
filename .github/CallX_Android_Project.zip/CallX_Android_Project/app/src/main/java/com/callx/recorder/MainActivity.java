package com.callx.recorder;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ = 41;
    private TextView status;
    private RadioButton mic, line;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(36, 48, 36, 24);

        TextView title = new TextView(this);
        title.setText("CallX\nضبط و مدیریت تماس");
        title.setTextSize(26);
        root.addView(title);

        TextView info = new TextView(this);
        info.setText("\nروش ضبط را انتخاب کن:");
        info.setTextSize(17);
        root.addView(info);

        RadioGroup modes = new RadioGroup(this);
        mic = new RadioButton(this);
        mic.setText("میکروفون گوشی (آزمایشی)");
        mic.setId(1);
        line = new RadioButton(this);
        line.setText("خط داخلی تماس");
        line.setId(2);
        modes.addView(mic);
        modes.addView(line);
        mic.setChecked(true);
        root.addView(modes);

        TextView warning = new TextView(this);
        warning.setText("\nحالت میکروفون ممکن است فقط صدای نزدیک گوشی را بگیرد. برای شنیده‌شدن طرف مقابل ممکن است بلندگوی گوشی لازم باشد. ضبط صدای داخلی تماس در این برنامه پشتیبانی نمی‌شود؛ اندروید معمولاً دسترسی آن را به برنامه‌های عادی نمی‌دهد.\n");
        root.addView(warning);

        Button start = new Button(this);
        start.setText("فعال‌سازی تشخیص خودکار تماس");
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("خاموش‌کردن");
        root.addView(stop);

        status = new TextView(this);
        status.setText("\nوضعیت: خاموش");
        status.setTextSize(16);
        root.addView(status);

        start.setOnClickListener(v -> {
            if (line.isChecked()) {
                status.setText("حالت خط تماس: روی این نسخه اندروید، دسترسی مستقیم تضمین‌شده نیست و ضبط شروع نمی‌شود.");
                return;
            }
            if (!hasPermissions()) {
                requestNeededPermissions();
                return;
            }
            Intent i = new Intent(this, CallMonitorService.class);
            i.setAction(CallMonitorService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            status.setText("وضعیت: پایش تماس روشن است. با شروع/دریافت تماس، ضبط میکروفون تلاش می‌شود.");
        });

        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, CallMonitorService.class);
            i.setAction(CallMonitorService.ACTION_STOP);
            startService(i);
            status.setText("وضعیت: خاموش");
        });

        setContentView(root);
    }

    private boolean hasPermissions() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            && checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNeededPermissions() {
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE}, REQ);
        }
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ) {
            boolean ok = true;
            for (int x : g) if (x != PackageManager.PERMISSION_GRANTED) ok = false;
            if (ok) Toast.makeText(this, "مجوزها داده شد؛ دوباره فعال‌سازی را بزن.", Toast.LENGTH_LONG).show();
            else Toast.makeText(this, "برای کار برنامه مجوزهای لازم داده نشد.", Toast.LENGTH_LONG).show();
        }
    }
}
